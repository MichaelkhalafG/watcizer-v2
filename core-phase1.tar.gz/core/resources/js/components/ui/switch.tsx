import * as React from 'react';
import * as SwitchPrimitive from '@radix-ui/react-switch';

import { cn } from '@/lib/utils';

/**
 * RTL note: the thumb travel uses `translate-x` with an RTL override rather than logical
 * properties, because transforms have no logical equivalent — in RTL the "on" position is to the
 * LEFT, and `rtl:data-[state=checked]:-translate-x-5` is what makes that true.
 */
const Switch = React.forwardRef<
    React.ElementRef<typeof SwitchPrimitive.Root>,
    React.ComponentPropsWithoutRef<typeof SwitchPrimitive.Root>
>(({ className, ...props }, ref) => (
    <SwitchPrimitive.Root
        ref={ref}
        className={cn(
            'peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors',
            'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
            'disabled:cursor-not-allowed disabled:opacity-50',
            'data-[state=checked]:bg-brand data-[state=unchecked]:bg-input',
            className,
        )}
        {...props}
    >
        <SwitchPrimitive.Thumb
            className={cn(
                'pointer-events-none block h-5 w-5 rounded-full bg-background shadow-lg ring-0 transition-transform',
                'data-[state=unchecked]:translate-x-0 data-[state=checked]:translate-x-5',
                'rtl:data-[state=checked]:-translate-x-5',
            )}
        />
    </SwitchPrimitive.Root>
));
Switch.displayName = 'Switch';

export { Switch };
