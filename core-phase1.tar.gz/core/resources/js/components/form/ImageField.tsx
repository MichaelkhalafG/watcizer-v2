import { ImageUp, Loader2, Trash2 } from 'lucide-react';
import { useCallback, useRef, useState } from 'react';

import { Field, type FieldShellProps } from '@/components/form/Field';
import { Button } from '@/components/ui/button';
import { Ltr } from '@/components/ui/bidi';
import { useT } from '@/lib/i18n';
import { cn } from '@/lib/utils';

export interface StoredImage {
    /** The filename the database stores — never a path, never a host (study §5.4). */
    file: string;
    folder: string;
    url: string;
    width: number;
    height: number;
    bytes: number;
    renditions: Record<string, Record<string, string>>;
    skipped: string[];
}

/**
 * Upload-with-preview, talking to `POST /manage/media`.
 *
 * Deliberately a plain `fetch` rather than an Inertia visit: an upload is not a page navigation,
 * and the form must keep the state the user already typed. The CSRF token comes from the cookie
 * Laravel already set, so no meta tag and no extra prop.
 *
 * The preview appears the moment a file is chosen (an object URL), and is swapped for the stored
 * URL when the server answers — so a slow connection still gets instant feedback.
 */
export function ImageField({
    type,
    value,
    onChange,
    disabled = false,
    compact = false,
    ...shell
}: FieldShellProps & {
    /** A key from config/media.php: product, product_gallery, brand, category, banner. */
    type: string;
    value: StoredImage | null;
    onChange: (image: StoredImage | null) => void;
    disabled?: boolean;
    /**
     * Inside a TABLE CELL: no dashed frame, no padding, a 40px preview and no file-path line.
     *
     * Added 2026-10-05 for the lookups screen, where one of these per row made every row 211px
     * tall and pushed the table off the side of a 1366px window. Same control, same upload, same
     * errors — a size that fits where it is being used.
     */
    compact?: boolean;
}) {
    const t = useT();
    const input = useRef<HTMLInputElement>(null);
    const [busy, setBusy] = useState(false);
    const [preview, setPreview] = useState<string | null>(null);
    const [failure, setFailure] = useState<string | null>(null);

    const upload = useCallback(
        async (file: File) => {
            setFailure(null);
            setPreview(URL.createObjectURL(file));
            setBusy(true);

            const body = new FormData();
            body.append('type', type);
            body.append('file', file);

            try {
                const response = await fetch('/manage/media', {
                    method: 'POST',
                    body,
                    headers: { Accept: 'application/json' },
                    credentials: 'same-origin',
                });
                const payload: unknown = await response.json();

                if (!response.ok) {
                    const message =
                        typeof payload === 'object' && payload !== null && 'message' in payload
                            ? String((payload as { message: unknown }).message)
                            : t('common.upload_failed', 'تعذّر رفع الصورة.');
                    setFailure(message);
                    setPreview(null);

                    return;
                }

                onChange(payload as StoredImage);
            } catch {
                setFailure(t('common.server_unreachable', 'تعذّر الاتصال بالخادم. حاول مرة أخرى.'));
                setPreview(null);
            } finally {
                setBusy(false);
            }
        },
        [onChange, type, t],
    );

    const shown = preview ?? value?.url ?? null;

    const replaceLabel = busy
        ? t('common.uploading', 'جارٍ الرفع…')
        : value === null
          ? t('form.choose_image', 'اختر صورة')
          : t('form.replace_image', 'استبدال');

    return (
        <Field
            {...shell}
            /*
             * In compact mode the visible label is dropped and kept for screen readers only: this
             * control sits in a table cell whose COLUMN HEADER already says «الشعار», and printing
             * it again on all 79 rows was 24px of every row saying what the header said once.
             * `inline` renders the control without the label column; the `aria-label` below keeps
             * the accessible name, so nothing is lost to a reader that cannot see the header.
             */
            labelHidden={compact}
            error={shell.error ?? failure}
            render={(attrs) => (
                <div className={compact ? undefined : 'space-y-3'}>
                    <div
                        className={cn(
                            'flex items-center',
                            compact
                                ? 'gap-2'
                                : 'gap-4 rounded-lg border border-dashed p-4',
                            disabled && 'opacity-60',
                            failure !== null && !compact && 'border-destructive/60',
                        )}
                    >
                        <div
                            className={cn(
                                'flex shrink-0 items-center justify-center overflow-hidden rounded-md border bg-muted/40',
                                compact ? 'h-10 w-10' : 'h-20 w-20',
                            )}
                            title={value?.file ?? undefined}
                        >
                            {shown !== null ? (
                                <img src={shown} alt="" className="h-full w-full object-contain" />
                            ) : (
                                <ImageUp className="h-6 w-6 text-muted-foreground" aria-hidden="true" />
                            )}
                        </div>

                        <div className="min-w-0 flex-1 space-y-2">
                            <input
                                {...attrs}
                                ref={input}
                                type="file"
                                accept="image/jpeg,image/png,image/webp,image/avif"
                                disabled={disabled || busy}
                                className="sr-only"
                                onChange={(event) => {
                                    const file = event.target.files?.[0];
                                    if (file !== undefined) {
                                        void upload(file);
                                    }
                                }}
                            />
                            <div className={cn('flex items-center gap-2', compact ? 'flex-nowrap' : 'flex-wrap')}>
                                <Button
                                    type="button"
                                    variant="outline"
                                    size={compact ? 'icon' : 'sm'}
                                    disabled={disabled || busy}
                                    onClick={() => input.current?.click()}
                                    className={compact ? 'h-8 w-8' : 'gap-2'}
                                    aria-label={compact ? replaceLabel : undefined}
                                    title={compact ? replaceLabel : undefined}
                                >
                                    {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <ImageUp className="h-4 w-4" aria-hidden="true" />}
                                    {compact ? null : replaceLabel}
                                </Button>
                                {value !== null ? (
                                    <Button
                                        type="button"
                                        variant="ghost"
                                        disabled={disabled || busy}
                                        onClick={() => {
                                            onChange(null);
                                            setPreview(null);
                                        }}
                                        size={compact ? 'icon' : 'sm'}
                                        className={cn('text-destructive', compact ? 'h-8 w-8' : 'gap-2')}
                                        aria-label={compact ? t('common.remove', 'إزالة') : undefined}
                                        title={compact ? t('common.remove', 'إزالة') : undefined}
                                    >
                                        <Trash2 className="h-4 w-4" aria-hidden="true" />
                                        {compact ? null : t('common.remove', 'إزالة')}
                                    </Button>
                                ) : null}
                            </div>

                            {/* The measurements are printed only when they were MEASURED (D-15).
                                A freshly uploaded image arrives with real numbers; one loaded from
                                a stored path arrives as zeros, because the path is all the row
                                holds. Every saved brand logo therefore read `… · 0×0 · 0 KB`
                                under a picture that was plainly neither. Zeros presented as
                                measurements are worse than no line: they say the file is broken.
                                The FILENAME is always shown, because that part is always known. */}
                            {value !== null && !compact ? (
                                <p className="truncate text-xs text-muted-foreground" title={value.file}>
                                    <Ltr>
                                        {value.file}
                                        {value.width > 0 && value.height > 0
                                            ? ` · ${value.width}×${value.height}`
                                            : ''}
                                        {value.bytes > 0 ? ` · ${Math.round(value.bytes / 1024)} KB` : ''}
                                        {Object.keys(value.renditions).length > 0
                                            ? ` · ${t('form.rendition_count', ':count أحجام', { count: Object.keys(value.renditions).length })}`
                                            : ''}
                                    </Ltr>
                                </p>
                            ) : null}

                            {/* When the host could not write AVIF, or a rendition was skipped because
                                the source was too small, say so here rather than in a log nobody reads. */}
                            {value !== null && !compact && value.skipped.length > 0 ? (
                                <ul className="space-y-0.5 text-[11px] text-amber-700 dark:text-amber-400">
                                    <Ltr>
                                        {value.skipped.map((reason) => (
                                            <li key={reason}>· {reason}</li>
                                        ))}
                                    </Ltr>
                                </ul>
                            ) : null}
                        </div>
                    </div>
                </div>
            )}
        />
    );
}
