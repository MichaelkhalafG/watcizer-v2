<?php

namespace App\Compat;

use App\Domain\Inventory\Actor;
use App\Domain\Inventory\InsufficientOfferStock;
use App\Domain\Inventory\InsufficientStock;
use App\Domain\Inventory\InventoryService;
use App\Domain\Notifications\OrderMailer;
use App\Domain\Promotions\PromotionOutcome;
use App\Support\Val;
use App\Transform\Row;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use RuntimeException;
use stdClass;

/**
 * The checkout half of the wave-3 compat layer: `POST add_order` and `GET callback_payment`,
 * reproducing `OrderController::AddOrder` / `CallbackPayment` while every stock mutation goes
 * through {@see InventoryService}.
 *
 * One behaviour is reproduced on purpose even though it looks like a defect, because the running
 * frontend depends on it and the harness compares bytes:
 *
 *  • (CLOSED 2026-09-23, security audit Finding 2.) This list used to say the buyer is taken from
 *    the request body and call that "mis-attribution rather than disclosure". The assessment was
 *    wrong: `billingData()` read the named customer's name, phone, street and e-mail onto a
 *    Paymob page whose URL went back to the caller, and `me/orders` read an unowned address back
 *    with its guest token. The buyer now comes from the JWT only, and the address must belong to
 *    that buyer — see `CheckoutCompatController::addOrder()`.
 *  • `items[]` from the client is the authoritative SET of lines. Prices are always recomputed
 *    server-side, so this is not a pricing hole; it exists because a stale DB cart row used to
 *    resurrect a line the shopper had removed and reject the checkout as a total mismatch.
 *
 * The order e-mails WERE the one thing this class did not reproduce. Wave 3 recorded each owed
 * message as an `integration_outbox` row (`channel = mail`) rather than pretending, and named the
 * port as switch-night prerequisite (a). That prerequisite was met on 2026-09-13: the templates
 * are ported, `App\Domain\Notifications\OrderMailer` is the sender, and the controller calls it
 * where this class used to write the placeholder row. The outbox rows are still written — they
 * are now the record of what was actually SENT, not a list of what is owed.
 */
final class CompatCheckout
{
    /**
     * @deprecated 2026-09-13 — use {@see OrderMailer::CHANNEL}. Kept
     *             because the wave-3 tests and the study's §4.2 prose name it; it holds the same
     *             value, which `OrderMailTriggersTest` asserts.
     */
    public const MAIL_CHANNEL = OrderMailer::CHANNEL;

    public function __construct(
        private readonly CompatCart $cart,
        private readonly InventoryService $inventory,
        private readonly int $storefrontId,
    ) {}

    /**
     * A resolved, server-priced line: what the order will actually store.
     *
     * Wave 3.5: a line naming a product that SELLS THROUGH VARIANTS is refused here. The compat
     * layer has no way to choose a size, and selling such a product at product level would
     * decrement an aggregate no variant backs. Unreachable on Watchizer — no storefront-1 product
     * has variants, asserted by `CompatVariantInvariantTest` — and a loud refusal if that ever
     * changes, rather than a silent oversell.
     *
     * @param  array<int, array{product_id: int|null, variant_id: int|null, offer_id: int|null, quantity: int, type_stock: string|null, color_band: string|null, color_dial: string|null}>  $lines
     * @return array{lines: list<array<string, mixed>>, total: float}|array{error: array<string, mixed>, status: int}
     */
    public function priceLines(array $lines): array
    {
        $productIds = [];
        $offerIds = [];
        foreach ($lines as $line) {
            if ($line['product_id'] !== null) {
                $productIds[$line['product_id']] = true;
            } elseif ($line['offer_id'] !== null) {
                $offerIds[$line['offer_id']] = true;
            }
        }
        $catalog = $this->cart->catalog(array_keys($productIds), array_keys($offerIds));

        $priced = [];
        $total = 0.0;
        foreach ($lines as $line) {
            $entity = null;
            if ($line['product_id'] !== null) {
                $entity = $catalog['products'][$line['product_id']] ?? null;
            } elseif ($line['offer_id'] !== null) {
                $entity = $catalog['offers'][$line['offer_id']] ?? null;
            }
            $qty = $line['quantity'];
            if ($entity === null || $qty < 1) {
                return ['error' => ['success' => false, 'message' => 'One of the items is no longer available.'], 'status' => 422];
            }
            if ($line['product_id'] !== null && ($catalog['products'][$line['product_id']]['has_variants'] ?? false)) {
                return ['error' => ['success' => false, 'message' => 'One of the items is no longer available.'], 'status' => 422];
            }
            $piece = CompatCart::catalogPrice($entity['selling'], $entity['sale']);
            $lineTotal = round($piece * $qty, 2);
            $priced[] = $line + ['piece_price' => $piece, 'total_price' => $lineTotal];
            $total += $lineTotal;
        }

        return ['lines' => $priced, 'total' => round($total, 2)];
    }

    /** The governorate's shipping cost for an address, rounded — 0.0 when either row is missing. */
    public function shippingCost(?int $addressId): float
    {
        if ($addressId === null) {
            return 0.0;
        }
        $cost = DB::table('addresses')
            ->join('shipping_cities', 'shipping_cities.id', '=', 'addresses.shipping_city_id')
            ->where('addresses.id', $addressId)
            ->value('shipping_cities.shipping_cost');

        return round((float) (is_scalar($cost) ? $cost : 0), 2);
    }

    /**
     * `str_pad(MAX(CAST(order_number AS UNSIGNED)) + 1, 6, '0', STR_PAD_LEFT)` under a
     * `lockForUpdate`, which serialises order creation exactly as the legacy app did. The lock is
     * the reason `orders` was never duplicated into the clean schema (study §2.6).
     */
    public function nextOrderNumber(): string
    {
        $max = DB::table('orders')->lockForUpdate()->selectRaw('MAX(CAST(order_number AS UNSIGNED)) as m')->value('m');

        return str_pad((string) ((int) (is_numeric($max) ? $max : 0) + 1), 6, '0', STR_PAD_LEFT);
    }

    /**
     * Insert the order and its lines, reserve the stock through the ledger, empty the cart.
     * Runs inside the caller's transaction; an InsufficientStock rolls the whole thing back.
     *
     * @param  list<array<string, mixed>>  $lines
     */
    public function placeOrder(
        ?int $userId,
        ?string $guestToken,
        int $addressId,
        float $total,
        string $paymentMethod,
        ?string $note,
        ?string $guestName,
        ?string $guestEmail,
        ?string $guestPhone,
        array $lines,
        /*
         * The winning promotion, or null. Appended and nullable so every existing caller — and the
         * wave-3 tests that drive this directly — keeps working unchanged, and so that "no
         * promotion" is the shape that costs nothing.
         */
        ?PromotionOutcome $promotion = null,
    ): int {
        $now = now();
        $orderId = (int) DB::table('orders')->insertGetId([
            'user_id' => $userId,
            'address_id' => $addressId,
            /*
             * The storefront this layer is pinned to (`config('compat.storefront_id')`, injected
             * above). It was already being handed to `commitOrder()` below, so the LEDGER has
             * recorded it since wave 3 while the order row it belongs to said NULL — wave 4C then
             * added this column, the payment callback started reading it, and nothing wrote it.
             *
             * That made the callback's ownership check (study §3.9.2 check 3) effectively
             * single-storefront: every order was NULL, NULL is accepted only for the primary
             * storefront, so the day Brand Fashion holds its own Paymob contract a BF order would
             * have been accepted against WATCHIZER's credentials — the exact cross-storefront
             * acceptance the two-level payment design exists to prevent.
             *
             * Not from the request host and not from a path segment: this layer answers the legacy
             * paths, which carry no storefront anywhere, and every builder in `CompatServices` is
             * constructed with this same value. A v2 checkout will take it from its
             * `/api/v2/{storefront}/…` segment instead, and the column then means the same thing on
             * both paths (developer decision 2026-09-13).
             */
            'storefront_id' => $this->storefrontId,
            'total_price_for_order' => $total,
            'payment_method' => $paymentMethod,
            'order_number' => $this->nextOrderNumber(),
            'note' => $note,
            'status' => $paymentMethod === 'cash' ? 'processing' : 'pending',
            'guest_name' => $guestName,
            'guest_email' => $guestEmail,
            'guest_phone' => $guestPhone,
            'guest_token' => $userId === null ? $guestToken : null,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        foreach ($lines as $line) {
            DB::table('order_items')->insert([
                'order_id' => $orderId,
                'product_id' => Val::nint($line, 'product_id'),
                'variant_id' => Val::nint($line, 'variant_id'),
                'offer_id' => Val::nint($line, 'offer_id'),
                'quantity' => Val::int($line, 'quantity'),
                'piece_price' => Val::str($line, 'piece_price'),
                'total_price' => Val::str($line, 'total_price'),
                'type_stock' => Val::nstr($line, 'type_stock'),
                'color_band' => Val::nstr($line, 'color_band'),
                'color_dial' => Val::nstr($line, 'color_dial'),
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }

        /*
         * ── the granted rewards, as REAL lines at zero price (wave 4D, D-24) ────────────────
         *
         * Written here, with the customer's own lines and BEFORE `commitOrder()`, which is what
         * makes reward stock inherit wave 3's guarantees instead of needing its own mechanism:
         * the commit below locks the order row and walks every persisted line, so the gift is
         * reserved inside the same transaction as the purchase, exactly once under concurrency,
         * and `releaseOrder()` gives it back on a cancellation with no new code at all.
         *
         * `piece_price` and `total_price` are '0.00' — which is why a granted reward does not move
         * `orders.total_price_for_order` and therefore cannot make `addOrder()`'s total check
         * disagree with the client. That property is the whole reason only the free-item reward
         * family ships before wave 9 (§3.16.9).
         */
        foreach ($promotion === null ? [] : $promotion->rewards as $reward) {
            DB::table('order_items')->insert([
                'order_id' => $orderId,
                'product_id' => $reward->productId,
                'variant_id' => $reward->variantId,
                'promotion_rule_id' => $reward->ruleId,
                'is_reward' => true,
                'offer_id' => null,
                'quantity' => $reward->quantity,
                'piece_price' => '0.00',
                'total_price' => '0.00',
                'type_stock' => $reward->typeStock,
                'color_band' => null,
                'color_dial' => null,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }

        // One door for stock. The legacy loop decremented in place between item inserts; the
        // ledger reads the persisted lines back, so the movements can never disagree with what
        // the order says it sold. Reward lines are in there too, reserved with their own reason.
        $this->inventory->commitOrder($orderId, Actor::user($userId), $this->storefrontId);

        return $orderId;
    }

    /** The order row, or null. */
    public function order(int $orderId): ?stdClass
    {
        $row = DB::table('orders')->where('id', $orderId)->first();

        return $row instanceof stdClass ? $row : null;
    }

    public function orderNumber(int $orderId): string
    {
        $value = DB::table('orders')->where('id', $orderId)->value('order_number');

        return is_scalar($value) ? (string) $value : '';
    }

    /**
     * The legacy 422 body for a failed reservation. Kept next to the exception so the two never
     * drift: `product_id` is present for a product line and absent for an offer line.
     *
     * @return array{body: array<string, mixed>, status: int}
     */
    public static function insufficientStockResponse(InsufficientStock|InsufficientOfferStock $e): array
    {
        if ($e instanceof InsufficientStock) {
            return ['body' => ['success' => false, 'message' => 'Insufficient stock', 'product_id' => $e->productId], 'status' => 422];
        }

        return ['body' => ['success' => false, 'message' => 'Insufficient offer stock'], 'status' => 422];
    }

    // ── Paymob ───────────────────────────────────────────────────────────────

    /**
     * Verify the HMAC Paymob sends with every transaction callback, over the 20 documented fields
     * in their documented order. Fails closed: no secret or no signature means rejected.
     *
     * @param  array<string, mixed>  $input
     */
    public function isValidPaymobHmac(array $input): bool
    {
        $secret = config('services.paymob.hmac_secret');
        if (! is_string($secret) || $secret === '') {
            return false;
        }
        $received = data_get($input, 'hmac');
        if (! is_scalar($received) || (string) $received === '') {
            return false;
        }

        $keys = [
            'amount_cents', 'created_at', 'currency', 'error_occured',
            'has_parent_transaction', 'id', 'integration_id', 'is_3d_secure',
            'is_auth', 'is_capture', 'is_refunded', 'is_standalone_payment',
            'is_voided', 'order', 'owner', 'pending',
            'source_data.pan', 'source_data.sub_type', 'source_data.type', 'success',
        ];
        $concatenated = '';
        foreach ($keys as $key) {
            $concatenated .= self::paymobField($input, $key);
        }

        return hash_equals(hash_hmac('sha512', $concatenated, $secret), (string) $received);
    }

    /**
     * One HMAC field, tolerating both the nested server callback (`obj.order.id`) and the
     * flattened redirect callback (`order`, `source_data_pan`).
     *
     * @param  array<string, mixed>  $input
     */
    public static function paymobField(array $input, string $key): string
    {
        if ($key === 'order') {
            $candidates = ['obj.order.id', 'order.id', 'order'];
        } elseif ($key === 'merchant_order_id') {
            /*
             * The MERCHANT reference — our own order key, echoed back by Paymob.
             *
             * It is NOT one of the twenty signed fields, so this arm cannot affect
             * {@see self::isValidPaymobHmac()}: that method walks a fixed, explicit list and this
             * name is not on it. It is here because the reference lives in a THIRD place in the
             * nested shape — `obj.order.merchant_order_id`, one level deeper than everything else
             * — and the handler that reads it had no way to find it (review 🔴-2).
             */
            $candidates = ['obj.order.merchant_order_id', 'order.merchant_order_id', 'merchant_order_id'];
        } elseif (str_starts_with($key, 'source_data.')) {
            $suffix = substr($key, strlen('source_data.'));
            $candidates = ['obj.'.$key, $key, 'source_data_'.$suffix];
        } else {
            $candidates = ['obj.'.$key, $key];
        }

        foreach ($candidates as $candidate) {
            /** @var mixed $value */
            $value = data_get($input, $candidate);
            if ($value !== null) {
                if (is_bool($value)) {
                    return $value ? 'true' : 'false';
                }

                return is_scalar($value) ? (string) $value : '';
            }
        }

        return '';
    }

    /**
     * Create the Paymob intention and return the unified-checkout URL.
     *
     * Paymob keys are developer-handled and never live in this repo, so this path is
     * STRUCTURALLY complete and locally UNPROVEN: with no keys configured it throws, which is the
     * same branch the legacy code takes, and the caller answers with the legacy 422. Only the
     * cash-on-delivery flow is exercised end to end by the harness.
     *
     * @param  array<string, mixed>  $billing
     * @return array{ok: true, redirect_url: string}|array{ok: false, error: string}
     */
    public function createPaymobIntention(float $amount, array $billing, int $orderId): array
    {
        $authToken = config('services.paymob.secret_key');
        $publicKey = config('services.paymob.public_key');
        if (! is_string($authToken) || $authToken === '' || ! is_string($publicKey) || $publicKey === '') {
            throw new RuntimeException('Paymob credentials not configured');
        }

        $methods = config('services.paymob.payment_methods');
        $response = Http::withHeaders([
            'Authorization' => "Token {$authToken}",
            'Content-Type' => 'application/json',
        ])->post('https://accept.paymob.com/v1/intention/', [
            'amount' => $amount * 100,
            'currency' => 'EGP',
            'payment_methods' => is_array($methods) ? array_values($methods) : [],
            'billing_data' => $billing,
            // Paymob requires special_reference to be globally unique forever; the numeric order
            // id stays the prefix so the callback's int coercion still resolves the order.
            'special_reference' => $orderId.'-'.time(),
        ]);

        if (! $response->successful()) {
            /*
             * The STATUS only, never Paymob's body (2026-09-24). This went to the buyer verbatim as
             * `paymob_error`, and the credential leak check showed a refusal body quoting the token
             * back reaching the browser whole. `PaymobProvider` already reports status only; this
             * wave-3 path is what production runs until a contract is entered, so it gets the same.
             */
            return ['ok' => false, 'error' => 'Paymob refused the intention (HTTP '.$response->status().').'];
        }

        $clientSecret = $response->json('client_secret');

        return ['ok' => true, 'redirect_url' => 'https://accept.paymob.com/unifiedcheckout/?publicKey='.$publicKey.'&clientSecret='.(is_scalar($clientSecret) ? (string) $clientSecret : '')];
    }

    /** Row helper re-export so the controller does not need two imports for one call. */
    public static function int(stdClass $row, string $column): int
    {
        return Row::int($row, $column);
    }
}
