<?php

namespace App\Http\Controllers\Compat;

use App\Compat\CartIdentity;
use App\Compat\CompatCheckout;
use App\Compat\CompatServices;
use App\Domain\Inventory\Actor;
use App\Domain\Inventory\InsufficientOfferStock;
use App\Domain\Inventory\InsufficientStock;
use App\Domain\Inventory\InventoryService;
use App\Domain\Notifications\OrderMailer;
use App\Domain\Payment\CallbackPolicy;
use App\Domain\Payment\PaymentInitiator;
use App\Domain\Promotions\CartLine;
use App\Domain\Promotions\CartSnapshot;
use App\Domain\Promotions\PromotionDiscounts;
use App\Domain\Promotions\PromotionEngine;
use App\Domain\Promotions\PromotionOutcome;
use App\Domain\Promotions\PromotionSkips;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Payment\PaymentCallbackController;
use App\Http\Middleware\CompatGuestCart;
use App\Support\Coerce;
use App\Support\DeadlockRetry;
use App\Support\LegacyJwt;
use App\Support\Val;
use App\Transform\Row;
use Illuminate\Database\Query\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Throwable;

/**
 * `POST add_order` and `GET callback_payment` — the two paths that mutate stock, moved onto
 * {@see InventoryService} (CLEAN_CORE_STUDY §3.3, §4.2).
 *
 * This is the endpoint the whole write-switch exists for: while it ran on the legacy app it
 * decremented legacy `products.stock`, which stops being the truth the moment the clean tables
 * are authoritative (risk register R2-01). Every response shape, every 422 message and the
 * order-number lock are unchanged; only where the stock number lives has moved.
 */
class CheckoutCompatController extends Controller
{
    public function __construct(
        private readonly CompatServices $compat,
        private readonly InventoryService $inventory,
        private readonly OrderMailer $mailer,
        private readonly PromotionEngine $promotions,
        private readonly PromotionSkips $skips,
        private readonly PaymentInitiator $initiator,
    ) {}

    /** POST add_order */
    /**
     * Roll back down to `$outer` and no further.
     *
     * A bare `DB::rollBack()` rolls back ONE level, and one level below our own is the caller's.
     * This is a loop rather than a single call because the level can be more than one above
     * `$outer` if something inside opened a nested transaction of its own.
     */
    private static function unwindTo(int $outer): void
    {
        while (DB::transactionLevel() > $outer) {
            DB::rollBack();
        }
    }

    public function addOrder(Request $request): JsonResponse
    {
        /*
         * ── Unwind to the level we FOUND, not to zero (2026-10-05) ──────────────────
         *
         * `DB::commit()` below is INSIDE this `try`, and four things run after it: the skipped-
         * promotion counter (a database write), the order e-mail, the Paymob leg (an outbound HTTP
         * call) and the order-number read. A throw from any of them lands in
         * `catch (Throwable) { DB::rollBack(); }` at a moment when this method's own transaction is
         * already committed — so the rollback unwinds whatever transaction is open OUTSIDE this
         * call instead.
         *
         * In production that is usually nothing. The test suite runs every request inside a
         * transaction, so it is the suite's, and once it is gone everything that TEST writes
         * afterwards is permanent — the same failure `PromotionController::preview()` was fixed
         * for on the same day. Found there by asserting `transactionLevel() >= 1` after every
         * test, and found here by an audit that went looking for the same shape.
         *
         * `$outer` makes every rollback in this method a no-op once our own transaction is gone,
         * which is the correct behaviour on all four paths.
         */
        $outer = DB::transactionLevel();

        /*
         * ── The BUYER comes from the JWT, never from the body (security audit, Finding 2) ─────
         *
         * This used to read `user_id` from the body, reproducing the legacy app. With an
         * `address_id` equally unowned, an anonymous caller could name ANY customer and ANY
         * address: `billingData()` loaded that person's name, phone, street and e-mail and put
         * them on the Paymob page whose URL was handed back to the caller; `me/orders` read the
         * address straight back with its `guest_token`; and the `server_total` 422 disclosed the
         * governorate of an address the caller did not own. The class docblock called the body
         * `user_id` "mis-attribution rather than disclosure" — it was disclosure.
         *
         * The storefront sends `user_id` in the body only when it ALSO sends the bearer token it
         * came from (`Checkout.jsx` derives `isLoggedIn` from that token), so a legitimate
         * checkout is byte-for-byte unchanged. A body `user_id` with no verified token behind it
         * — or naming somebody else — is answered exactly as `compat.auth` answers any
         * unauthenticated account call: 401 `{"message":"Unauthenticated."}`. The storefront's response
         * interceptor already signs the shopper out on a 401, which is the right outcome for the
         * one legitimate way to arrive here: an expired session.
         */
        $userId = LegacyJwt::userId($request);
        if ($request->filled('user_id')) {
            $claimed = Coerce::nint($request->input('user_id'));
            if ($userId === null || $claimed !== $userId) {
                return response()->json(['message' => 'Unauthenticated.'], 401);
            }
        }
        $isGuest = $userId === null;
        $guestToken = $this->guestToken($request);

        DB::beginTransaction();

        try {
            $data = Validator::make($request->all(), [
                'user_id' => 'nullable|integer',
                /*
                 * The address must be the BUYER's: the account's own, or — for a guest — one this
                 * guest session created. One rule rather than `exists` plus a later check, so a
                 * foreign address and a non-existent one produce the SAME validation message:
                 * the bare `exists` rule was itself an oracle for which address ids are real.
                 */
                'address_id' => ['required_without:address_line', 'nullable', 'integer',
                    Rule::exists('addresses', 'id')->where(function (Builder $query) use ($userId, $guestToken): void {
                        if ($userId !== null) {
                            $query->where('user_id', $userId);
                        } elseif ($guestToken !== null) {
                            $query->whereNull('user_id')->where('guest_token', $guestToken);
                        } else {
                            // No guest session at all means no address can be this caller's.
                            $query->whereRaw('1 = 0');
                        }
                    }),
                ],
                'address_line' => 'required_without:address_id|nullable|string|min:3|max:500',
                'shipping_city_id' => 'required_without:address_id|nullable|integer|exists:shipping_cities,id',
                'phone' => 'required_without:address_id|nullable|string|min:7|max:20',
                'total_price_for_order' => 'required|numeric|min:0',
                'payment_method' => 'required|in:cash,card,paymob,whatsapp',
                'note' => 'nullable|string|max:1000',
                'guest_name' => 'nullable|string|max:255',
                'guest_phone' => 'nullable|string|max:20',
                'guest_email' => 'nullable|email|max:255',
                'items' => 'nullable|array',
                'items.*.product_id' => ['nullable', 'integer', Rule::exists('catalog_products', 'id')->whereNull('deleted_at')],
                'items.*.offer_id' => 'nullable|integer|exists:offers,id',
                'items.*.quantity' => 'required_with:items|integer|min:1',
                'items.*.piece_price' => 'required_with:items|numeric|min:0',
                'items.*.total_price' => 'required_with:items|numeric|min:0',
                'items.*.type_stock' => 'nullable|in:Express,Market',
                'items.*.color_band' => 'nullable|string',
                'items.*.color_dial' => 'nullable|string',
            ])->validate();

            // The buyer and the guest session were resolved above, before the transaction.

            $paymentMethod = Val::str($data, 'payment_method') === 'card' ? 'paymob' : Val::str($data, 'payment_method');

            // ── shipping address ────────────────────────────────────────────────
            $addressId = $request->filled('address_id') ? Val::nint($data, 'address_id') : null;
            if ($addressId === null) {
                $phone = $request->input('phone') ?? $request->input('guest_phone') ?? '';
                $addressId = $this->compat->account->createAddress(
                    $userId,
                    $guestToken,
                    Val::int($data, 'shipping_city_id'),
                    trim(Val::str($data, 'address_line')),
                    trim(is_scalar($phone) ? (string) $phone : ''),
                    null,
                );
            }

            // ── the lines ───────────────────────────────────────────────────────
            $cart = null;
            $lines = $this->requestLines($request);
            if (! $isGuest) {
                $cart = $this->compat->cart->find(CartIdentity::user($userId));
                if ($lines === [] && $cart !== null) {
                    $lines = $this->cartLines(Row::int($cart, 'id'));
                }
            }
            if ($lines === []) {
                self::unwindTo($outer);

                return response()->json(['success' => false, 'message' => 'Cart is empty'], 422);
            }

            // ── authoritative server-side pricing ───────────────────────────────
            $priced = $this->compat->checkout->priceLines($lines);
            if (isset($priced['error'])) {
                self::unwindTo($outer);

                return response()->json($priced['error'], 422);
            }

            $serverTotal = round($priced['total'] + $this->compat->checkout->shippingCost($addressId), 2);
            $clientTotal = round((float) Val::str($data, 'total_price_for_order'), 2);
            if (abs($clientTotal - $serverTotal) > 0.01) {
                self::unwindTo($outer);

                return response()->json([
                    'success' => false,
                    'message' => 'Order total mismatch — your cart may be out of date. Please review and try again.',
                    'server_total' => $serverTotal,
                ], 422);
            }

            /*
             * ── promotions (wave 4D, study §3.16) ─────────────────────────────────────────────
             *
             * Evaluated HERE: after the authoritative pricing, because a rule reads the server's
             * own subtotal and never the client's; and before `placeOrder()`, because a granted
             * reward is a line of the order being written.
             *
             * ── The total guard is ABOVE this, and it stays there ─────────────────────────────
             *
             * The client's number has already been compared against the server's own UNDISCOUNTED
             * total and accepted. A promotion is applied to the order total only after that, which
             * keeps two properties at once:
             *
             *  - the anti-tampering guard is exactly what it was. A client that sends the wrong
             *    total is still refused, on the same arithmetic, with the same message. Nothing
             *    about the discount is negotiable by the caller — it is computed here, from rules
             *    the client never sees.
             *  - a money-reducing reward no longer 422s the checkout that earned it. The order
             *    simply carries a smaller total than the cart quoted.
             *
             * The second point is a DISCLOSURE problem rather than a correctness one, and it is why
             * the money family is unlocked per storefront: a frontend that cannot show the discount
             * would quote one number and charge a smaller one. `PromotionRules::isRewardAvailableOn`
             * refuses those rewards on any storefront whose settings have not said otherwise, so a
             * storefront that has never heard of the setting behaves precisely as it did before.
             *
             * `evaluate()` writes nothing. The refusals it reports are recorded AFTER the
             * transaction, below — a skip is a fact about an attempt that happened, and it must
             * survive the order rolling back.
             */
            $promotion = $this->evaluatePromotions($priced, $addressId, $paymentMethod);

            /*
             * Clamped at zero, belt and braces. `PromotionRules::discountFor()` already caps each
             * reward at what the cart can bear, but the order total is the number a payment
             * provider is charged and a courier collects: it is worth one more line here to make a
             * negative total unrepresentable rather than merely unreachable.
             */
            if ($promotion->discount > 0.0) {
                $serverTotal = round(max(0.0, $serverTotal - $promotion->discount), 2);
            }

            $orderId = $this->compat->checkout->placeOrder(
                $userId,
                $guestToken,
                $addressId,
                $serverTotal,
                $paymentMethod,
                $this->nullableString($request->input('note')),
                $this->nullableString($request->input('guest_name')),
                $this->nullableString($request->input('guest_email')),
                $this->nullableString($request->input('guest_phone') ?? $request->input('phone')),
                $priced['lines'],
                $promotion,
            );

            /*
             * ── The discount's audit trail (M1r) ──────────────────────────────────────────────
             *
             * A free-item reward is already explained by its own `order_items` row. A money reward
             * is only a smaller total, so the reason has to be recorded deliberately — otherwise an
             * order whose lines sum to 500 and whose total reads 475 has nothing to say why, and
             * the settlement export cannot attribute the difference.
             *
             * INSIDE the transaction, unlike the skip counter below: a skip is a fact about an
             * ATTEMPT and must survive the order rolling back, while this is a fact about an ORDER
             * and must not exist if that order does not.
             */
            PromotionDiscounts::record($orderId, $promotion);

            // Clear the cart so an ordered/removed line can never inflate the NEXT order's total.
            if (! $isGuest && $cart !== null) {
                $this->compat->cart->destroy(Row::int($cart, 'id'));
            } elseif ($isGuest && $guestToken !== null) {
                $guestCart = $this->compat->cart->find(CartIdentity::guest($guestToken));
                if ($guestCart !== null) {
                    $this->compat->cart->destroy(Row::int($guestCart, 'id'));
                }
            }

            DB::commit();

            /*
             * The promotions that MATCHED this cart and were refused — recorded after the commit,
             * outside the transaction, for the same reason the lost-callback finding is: the
             * attempt happened whether or not the order survived, and an admin whose gift is never
             * delivered learns it from this counter and nothing else. The customer saw the cart
             * they would have had, which is the requirement.
             */
            $this->skips->record($promotion->skipped, $this->compat->storefrontId);

            /*
             * -- order e-mail (prerequisite (a), 2026-09-13) --------------------------------
             *
             * AFTER `DB::commit()`, exactly where the legacy app sends it (`sendOrderEmails()`:
             * "this runs after DB::commit(), so the order is already safely persisted"). The
             * condition is the legacy condition: only a COD or WhatsApp order mails at checkout,
             * and only COD mails the CUSTOMER -- a card order tells the customer when the callback
             * says the money arrived, not when they clicked pay.
             *
             * Nothing here can fail the request: `OrderMailer` records every outcome as an outbox
             * row and throws at nobody. Until this line existed, core wrote a row saying the mail
             * was owed and sent nothing.
             */
            if (in_array($paymentMethod, ['cash', 'whatsapp'], true)) {
                $this->mailer->placedNow($orderId, notifyCustomer: $paymentMethod === 'cash');
            }

            if ($paymentMethod === 'paymob') {
                return $this->paymob($request, $orderId, $userId, $addressId);
            }

            return response()->json([
                'success' => true,
                'message' => 'Order placed successfully',
                'order_number' => $this->compat->checkout->orderNumber($orderId),
            ], 200);
        } catch (InsufficientStock|InsufficientOfferStock $e) {
            self::unwindTo($outer);
            $response = CompatCheckout::insufficientStockResponse($e);

            return response()->json($response['body'], $response['status']);
        } catch (ValidationException $e) {
            self::unwindTo($outer);

            return response()->json(['success' => false, 'message' => 'Validation failed', 'errors' => $e->errors()], 422);
        } catch (Throwable $e) {
            self::unwindTo($outer);
            Log::error($e);

            return response()->json(['success' => false, 'message' => 'An error occurred', 'ref' => (string) Str::uuid()], 500);
        }
    }

    /**
     * GET callback_payment — Paymob's transaction callback.
     *
     * Four things happen in ONE transaction (review 🟠-4): the `payment_statuses` row, the order's
     * status change, the e-mail record and the stock release. The first version wrote them as
     * separate statements, so a failure between them could leave a payment recorded against an
     * order that was never updated, or an order cancelled whose stock was never returned. They are
     * one unit now, and `payment_statuses.pay_transaction_id` carries a UNIQUE index (M1e) so a
     * Paymob retry that races the idempotency check is refused by the database rather than
     * processed twice.
     *
     * It also verifies the AMOUNT (review 🟡-5). Paymob's `amount_cents` must equal the order's
     * own total to the cent; a mismatch is **failed closed** — the payment row is recorded for the
     * audit trail, the order is left exactly as it was, and the shopper is redirected with the
     * error flag. Marking an order paid on a callback whose amount disagrees with the order is
     * how an underpayment becomes a shipped parcel. This is a deliberate deviation from the
     * legacy behaviour, which never compared the two (D-23).
     */
    public function callbackPayment(Request $request): JsonResponse|RedirectResponse
    {
        try {
            /** @var array<string, mixed> $input */
            $input = $request->all();
            if (! $this->compat->checkout->isValidPaymobHmac($input)) {
                return response()->json(['message' => 'Invalid signature'], 403);
            }

            /*
             * ── Every identifier through `paymobField()`, like the outcome beside them (🔴-2) ──
             *
             * These four were `$request->input(...)`, which reads the TOP LEVEL only. That was
             * harmless while this handler could only be reached by the shopper's browser on a GET,
             * where the twenty fields are flattened into the query string. Registering POST on
             * `callback_payment` (§4A.2) changed it: the PROCESSED callback nests everything under
             * `obj.*`, and the alias falls through to this method whenever the Paymob contract is
             * not live yet.
             *
             * The signature verified — `isValidPaymobHmac()` has always read through the
             * extractor — and then all four of these read NULL on the same payload. Measured, with
             * a genuine signed success: the order stayed `pending` with the money taken, and a
             * `payment_statuses` row was written naming no order, no transaction and no amount.
             * Worse, the idempotency lookup below keys on that null transaction id, so it never
             * matched and Paymob's retries each wrote another orphan row.
             *
             * `CompatCheckout::paymobField()` is the ONE extractor that reads both shapes, which
             * is why `CallbackPolicy::outcomeFromPaymob()` was moved onto it in the same review.
             * Half a handler reading one shape and half reading the other is how the two deliveries
             * of one payment reach two different verdicts.
             *
             * It returns `''` for a field it cannot find, and `''` must stay NULL here rather than
             * becoming `0`: a null amount means "nothing to compare" to `paymobAmountMismatch()`,
             * where a zero would mean "the shopper paid nothing" and fail the order closed.
             */
            $field = static fn (string $key): ?string => ($v = CompatCheckout::paymobField($input, $key)) === '' ? null : $v;

            $transactionId = $field('id');
            $transactionId = $transactionId === null ? null : (int) $transactionId;
            if ($transactionId !== null && DB::table('payment_statuses')->where('pay_transaction_id', $transactionId)->exists()) {
                return response()->json(['message' => 'Already processed'], 200);
            }

            /*
             * The merchant reference the wave-3 intention sent is `<order id>-<timestamp>`
             * (`CompatCheckout::createPaymobIntention()`), so the integer prefix IS the order id
             * and the coercion below is deliberate rather than lax. Unchanged — only WHERE the
             * value is read from has moved.
             */
            $merchantOrderId = $field('merchant_order_id');
            $orderId = $merchantOrderId !== null && (int) $merchantOrderId > 0 ? (int) $merchantOrderId : null;
            $amountCentsRaw = $field('amount_cents');
            $amountCents = $amountCentsRaw === null ? null : (int) $amountCentsRaw;

            $amountMismatch = $this->paymobAmountMismatch($orderId, $amountCents);

            /*
             * ── What this callback is ALLOWED to do (🔴-1, review of 2026-09-13) ────────────
             *
             * This handler is the one Paymob calls TODAY, and until 2026-09-13 it moved the order
             * unconditionally: success → `processing`, failure → `cancelled` + release stock,
             * whatever state the order was in. The idempotency guard above only catches a replay of
             * the SAME transaction id, so a retry after a decline re-marked a cancelled order as
             * paid with its stock already back on the shelf, and a refund (`success=true` with
             * `is_refunded=true`) read as a fresh sale.
             *
             * The decision now lives in ONE place shared with the wave-4C handler, so the two
             * cannot drift: `App\Domain\Payment\CallbackPolicy`.
             */
            /** @var array<string, mixed> $payload */
            $payload = $input;
            $outcome = CallbackPolicy::outcomeFromPaymob($payload);

            /*
             * The mail rows the transaction below may enqueue. Declared out here because they are
             * written INSIDE it and sent AFTER it: an SMTP round trip inside a transaction holds
             * row locks for seconds, and a row marked `sent` inside a transaction that then rolls
             * back is how a customer gets told twice.
             *
             * @var list<int> $mailIds
             */
            $mailIds = [];
            $order = $orderId === null ? null : $this->compat->checkout->order($orderId);
            $orderStatus = $order === null ? null : Row::str($order, 'status');
            $decision = CallbackPolicy::decide($outcome, $orderStatus ?? 'pending', $amountMismatch === null);

            // Built BEFORE the transaction, so the fallback can write it if the commit is lost.
            $attemptRow = [
                'order_id' => $merchantOrderId === null ? null : (int) $merchantOrderId,
                'pay_order_id' => ($payOrder = $field('order')) === null ? null : (int) $payOrder,
                'pay_transaction_id' => $transactionId,
                'amount_cents' => $amountCents,
                // An amount that disagrees with the order is never recorded as a success, whatever
                // Paymob said.
                'success' => $decision['paid'] ? 'true' : 'false',
                // …and what it actually was: a refund, a void and a decline are three things that
                // `success` cannot tell apart (🟡-4).
                'outcome' => $outcome,
            ];

            try {
                /*
                 * Bounded deadlock retry, the same policy `InventoryService` uses (2026-09-13).
                 * This is the handler Paymob calls TODAY, and it locks the order row and then its
                 * products — the same rows in the same order as the stock service, so the two
                 * deadlock against each other under concurrency. A deadlocked callback used to
                 * answer 500 with every trace of the attempt rolled back.
                 */
                DeadlockRetry::run(function () use ($transactionId, $orderId, $amountMismatch, $order, $orderStatus, $outcome, $decision, $attemptRow, &$mailIds): void {
                    $now = now();
                    $attemptId = (int) DB::table('payment_statuses')->insertGetId($attemptRow + [
                        'created_at' => $now,
                        'updated_at' => $now,
                    ]);

                    if ($decision['finding'] !== null) {
                        CallbackPolicy::record(
                            $decision['finding'],
                            'paymob',
                            $orderId,
                            $attemptId,
                            $outcome,
                            $orderStatus,
                            $amountCents = $attemptRow['amount_cents'],
                            ['transaction' => $transactionId, 'route' => 'legacy_alias', 'amount_mismatch' => $amountMismatch],
                        );
                    }

                    if ($orderId === null || $order === null) {
                        return;
                    }

                    if ($decision['action'] === CallbackPolicy::ACT_PAY) {
                        DB::table('orders')->where('id', $orderId)->update(['status' => 'processing', 'updated_at' => now()]);
                        /*
                         * ENQUEUED inside the transaction, SENT after it (see `$mailIds` below).
                         * The obligation commits with the payment or rolls back with it -- an order
                         * whose payment row vanished must not have told the customer it arrived --
                         * and the SMTP round trip happens outside, where it holds no row locks.
                         *
                         * The legacy app calls `sendOrderEmails($order, $isGuest, 'cash')` here,
                         * i.e. customer AND admins, which is why `notifyCustomer` is true: the
                         * money is in, so this is the same confirmation a COD shopper gets at
                         * checkout.
                         */
                        $mailIds = $this->mailer->placed($orderId, notifyCustomer: true);
                    } elseif ($decision['action'] === CallbackPolicy::ACT_CANCEL) {
                        DB::table('orders')->where('id', $orderId)->update(['status' => 'cancelled', 'updated_at' => now()]);
                        $this->inventory->releaseOrder($orderId, 'payment_failed', Actor::system(), $this->compat->storefrontId);
                    }
                    // Every other decision: the attempt is on record, a finding is raised, and the
                    // ORDER IS NOT TOUCHED. Stock is never re-reserved here — the units may be gone.
                });
            } catch (Throwable $e) {
                /*
                 * ONLY CONTENTION lands here — a deadlock that outlived the retries, or a
                 * lock-wait timeout (which is never retried, because hammering the holder makes it
                 * worse). Anything else is
                 * deterministic — a foreign key, a bug, a broken config — and it is re-thrown
                 * untouched so that:
                 *
                 *   - the transaction's all-or-nothing property stays exactly as wave 3 proved it
                 *     (`PaymobCallbackTest`: a failing release rolls the payment row back with it), and
                 *   - a callback naming an order that does not exist is still refused the way the
                 *     LEGACY app refuses it, which the compat layer reproduces on purpose.
                 *
                 * Those failures repeat on the provider's next retry, which is what should happen:
                 * recording them as "reconciliation" would file a bug under money.
                 */
                if (! ($e instanceof QueryException) || ! DeadlockRetry::isContention($e)) {
                    throw $e;
                }

                /*
                 * Retries spent on a genuine deadlock. The attempt and a finding are written
                 * OUTSIDE the rolled-back transaction — inside it they would be rolled back too,
                 * which is how a real payment disappears — and the order is left exactly as this
                 * callback found it.
                 */
                CallbackPolicy::recordLostCallback(
                    'paymob',
                    $orderId,
                    $orderStatus,
                    $outcome,
                    $attemptRow,
                    $e,
                    ['route' => 'legacy_alias', 'amount_mismatch' => $amountMismatch],
                );

                // 200 rather than 500, so the provider does not retry straight back into the same
                // contention: the money is on record and a human has been handed the discrepancy.
                return response()->json(['message' => 'Recorded for reconciliation'], 200);
            }

            /*
             * The transaction committed, so the order really is paid -- NOW the e-mail goes.
             *
             * Deliberately outside the `try` above and before the redirect: a shopper coming back
             * from Paymob should not wait on a relay, but they should not be redirected before the
             * attempt is made either, because inline sending is what makes the confirmation arrive
             * while they are still looking at the thank-you page. A failure here costs the shopper
             * nothing -- the row stays pending and the cron retries.
             */
            $this->mailer->flush($mailIds);

            if ($amountMismatch !== null) {
                Log::error('Paymob callback amount does not match the order total; order left untouched.', $amountMismatch);

                return self::callbackDone($request, false);
            }

            /*
             * `true` unconditionally, and that is the LEGACY behaviour preserved rather than an
             * oversight: this handler redirects a returning shopper to the storefront root whether
             * the payment succeeded or was declined, and only an AMOUNT MISMATCH gets the error
             * flag. The compat harness compares that redirect byte for byte, so the GET arm must
             * not start distinguishing outcomes now. What changes is only the POST arm, which had
             * no answer of its own at all.
             */
            return self::callbackDone($request, true);
        } catch (Throwable $e) {
            Log::error($e);

            return self::callbackDone($request, false);
        }
    }

    /**
     * How this handler answers — the SAME rule the wave-4C handler uses, not a second copy.
     *
     * A browser gets the redirect it has always got; a server-to-server POST gets JSON with 200,
     * which is what stops Paymob retrying (review 🔴-2). Delegated to
     * {@see PaymentCallbackController::done()} so the two handlers that share one URL cannot
     * disagree about what a POST means.
     */
    private static function callbackDone(Request $request, bool $ok, ?string $message = null): JsonResponse|RedirectResponse
    {
        return PaymentCallbackController::done($request, $ok, $message);
    }

    /**
     * Build the snapshot and ask the engine. Never throws at the checkout: a promotion that cannot
     * be evaluated is a promotion that does not apply.
     *
     * @param  array{lines: list<array<string, mixed>>, total: float}  $priced
     */
    private function evaluatePromotions(array $priced, int $addressId, string $paymentMethod): PromotionOutcome
    {
        $lines = [];
        foreach ($priced['lines'] as $line) {
            $lines[] = new CartLine(
                productId: Val::nint($line, 'product_id'),
                variantId: Val::nint($line, 'variant_id'),
                offerId: Val::nint($line, 'offer_id'),
                quantity: Val::int($line, 'quantity'),
                unitPrice: (float) Val::str($line, 'piece_price'),
                typeStock: Val::nstr($line, 'type_stock'),
            );
        }

        $snapshot = new CartSnapshot(
            storefrontId: $this->compat->storefrontId,
            lines: $lines,
            // The SERVER's subtotal, from `priceLines()`. A condition that read the client's
            // number would be a discount a shopper could grant themselves.
            subtotal: $priced['total'],
            shippingCost: $this->compat->checkout->shippingCost($addressId),
            paymentMethod: $paymentMethod,
        );

        return $this->promotions->evaluate($snapshot);
    }

    /**
     * Does the callback's `amount_cents` disagree with what the order says it costs?
     *
     * Returns null when the two agree (or when there is nothing to compare against, which is the
     * legacy shape for a callback carrying no resolvable order), and the log context otherwise.
     * Compared in integer cents with a one-cent tolerance, because the order total is a
     * DECIMAL(12,2) and the multiplication by 100 is floating point.
     *
     * @return array<string, mixed>|null
     */
    private function paymobAmountMismatch(?int $orderId, ?int $amountCents): ?array
    {
        if ($orderId === null || $amountCents === null) {
            return null;
        }
        $order = $this->compat->checkout->order($orderId);
        if ($order === null) {
            return null;
        }

        $expected = (int) round(((float) Row::money($order, 'total_price_for_order')) * 100);
        if (abs($expected - $amountCents) <= 1) {
            return null;
        }

        return [
            'order_id' => $orderId,
            'order_number' => Row::str($order, 'order_number'),
            'expected_amount_cents' => $expected,
            'callback_amount_cents' => $amountCents,
        ];
    }

    // ── helpers ──────────────────────────────────────────────────────────────

    /**
     * The client-sent `items[]`, normalised. This is the authoritative SET of lines; prices are
     * always recomputed, so trusting the client for the set is not a pricing hole.
     *
     * Wave 3.5: `variant_id` is deliberately NOT read from the request. The legacy frontend has
     * no concept of a variant, so a compat line is always variant-free; that is the invariant, and
     * accepting the field would create the one thing the invariant forbids.
     *
     * @return array<int, array{product_id: int|null, variant_id: int|null, offer_id: int|null, quantity: int, type_stock: string|null, color_band: string|null, color_dial: string|null}>
     */
    private function requestLines(Request $request): array
    {
        $items = $request->input('items');
        if (! is_array($items)) {
            return [];
        }
        $lines = [];
        foreach ($items as $item) {
            if (! is_array($item)) {
                continue;
            }
            /** @var array<string, mixed> $item */
            $lines[] = [
                'product_id' => Val::nint($item, 'product_id'),
                'variant_id' => null,
                'offer_id' => Val::nint($item, 'offer_id'),
                'quantity' => Val::int($item, 'quantity'),
                'type_stock' => Val::nstr($item, 'type_stock'),
                'color_band' => Val::nstr($item, 'color_band'),
                'color_dial' => Val::nstr($item, 'color_dial'),
            ];
        }

        return $lines;
    }

    /**
     * The DB cart, used only when a logged-in client posted no `items[]` at all.
     *
     * @return array<int, array{product_id: int|null, variant_id: int|null, offer_id: int|null, quantity: int, type_stock: string|null, color_band: string|null, color_dial: string|null}>
     */
    private function cartLines(int $cartId): array
    {
        $lines = [];
        foreach ($this->compat->cart->items($cartId) as $item) {
            $lines[] = [
                'product_id' => Row::nint($item, 'product_id'),
                'variant_id' => Row::nint($item, 'variant_id'),
                'offer_id' => Row::nint($item, 'offer_id'),
                'quantity' => Row::int($item, 'quantity'),
                'type_stock' => Row::nstr($item, 'type_stock'),
                'color_band' => Row::nstr($item, 'color_band'),
                'color_dial' => Row::nstr($item, 'color_dial'),
            ];
        }

        return $lines;
    }

    /**
     * The Paymob branch — the storefront's OWN contract first, the wave-3 path while none is live.
     *
     * ── Why initiation and verification must move together (wave 4D, task C2) ────────────────
     *
     * Until this branch asked the table, a customer could be sent to ONE Paymob account to pay
     * while the callback was verified against ANOTHER account's HMAC secret — because wave 4C moved
     * verification onto `storefront_payment_providers` and initiation was still reading
     * `config('services.paymob.*')`. The symptom would be a signature that does not verify, with
     * the money taken and the order left pending, which reads like a provider outage rather than a
     * configuration split across two places.
     *
     * `PaymentInitiator` asks the SAME question the callback's `aliasIsLive()` asks — contract
     * enabled AND credentials present — and answers null when it is not yet true. So inserting the
     * credentials cuts BOTH halves over at once, with no deploy, and disabling the contract moves
     * both back. Prerequisite (d) closes here.
     *
     * The keys themselves are developer-handled and never in this repo, so with nothing configured
     * either path fails the same way: the legacy "Payment could not be initiated" 422, which is the
     * branch the legacy code takes for the same reason.
     */
    private function paymob(Request $request, int $orderId, ?int $userId, int $addressId): JsonResponse
    {
        $orderNumber = $this->compat->checkout->orderNumber($orderId);
        $order = $this->compat->checkout->order($orderId);
        $amount = $order === null ? 0.0 : (float) Row::money($order, 'total_price_for_order');
        $billing = $this->billingData($request, $userId, $addressId);

        try {
            $contracted = $this->initiator->initiate(
                // The host serving THIS request is the host the provider must call back to.
                $request,
                $this->compat->storefrontId,
                app()->getLocale(),
                Coerce::nstr($request->input('payment_method_id')) ?? Coerce::nstr($request->input('payment_method')),
                $orderId,
                $orderNumber,
                $amount,
                $billing,
            );

            if ($contracted !== null) {
                if ($contracted->ok && $contracted->checkoutUrl !== null) {
                    return response()->json([
                        'success' => true,
                        'order_number' => $orderNumber,
                        'redirect_url' => $contracted->checkoutUrl,
                    ], 200);
                }

                // Refused by the provider: give the reserved stock back and cancel, exactly as the
                // wave-3 path does. The REASON is the provider's own sentence and carries no key.
                $this->cancelAndRelease($orderId);

                return response()->json([
                    'success' => false,
                    'message' => 'Payment session failed',
                    'order_number' => $orderNumber,
                    'paymob_error' => $contracted->failureReason,
                ], 422);
            }

            $result = $this->compat->checkout->createPaymobIntention($amount, $billing, $orderId);

            if ($result['ok']) {
                return response()->json(['success' => true, 'order_number' => $orderNumber, 'redirect_url' => $result['redirect_url']], 200);
            }

            // Session refused → give the reserved stock back and CANCEL the order (never delete:
            // order_items and payment_statuses reference it with ON DELETE RESTRICT).
            $this->cancelAndRelease($orderId);

            return response()->json([
                'success' => false,
                'message' => 'Payment session failed',
                'order_number' => $orderNumber,
                'paymob_error' => $result['error'],
            ], 422);
        } catch (Throwable $e) {
            Log::error($e);
            $this->cancelAndRelease($orderId);

            return response()->json([
                'success' => false,
                'message' => 'Payment could not be initiated. Please try again or choose Cash on Delivery.',
                'order_number' => $orderNumber,
            ], 422);
        }
    }

    private function cancelAndRelease(int $orderId): void
    {
        $this->inventory->releaseOrder($orderId, 'payment_failed', Actor::system(), $this->compat->storefrontId);
        DB::table('orders')->where('id', $orderId)->update(['status' => 'cancelled', 'updated_at' => now()]);
    }

    /** @return array<string, string> */
    private function billingData(Request $request, ?int $userId, int $addressId): array
    {
        $first = 'Guest';
        $last = 'User';
        $email = 'guest@example.com';

        $user = $userId === null ? null : DB::table('users')->where('id', $userId)->first();
        if ($user !== null) {
            $first = Row::nstr($user, 'first_name') ?? 'Guest';
            $last = Row::nstr($user, 'last_name') ?? 'User';
            $email = Row::nstr($user, 'email') ?? 'guest@example.com';
        } else {
            $parts = explode(' ', trim((string) ($this->nullableString($request->input('guest_name')) ?? 'Guest User')), 2);
            $first = ($parts[0] !== '' ? $parts[0] : 'Guest');
            $last = $parts[1] ?? 'User';
            $email = $this->nullableString($request->input('guest_email')) ?? 'guest@example.com';
        }

        $address = DB::table('addresses')->where('id', $addressId)->first();
        $street = $address === null ? 'N/A' : (Row::nstr($address, 'address_line') ?? 'N/A');
        $phone = $address === null ? null : Row::nstr($address, 'phone_number_one');
        $phone ??= $this->nullableString($request->input('guest_phone')) ?? '01000000000';

        $city = 'Cairo';
        if ($address !== null) {
            $name = DB::connection('legacy')->table('shipping_city_translations')
                ->where('shipping_city_id', Row::int($address, 'shipping_city_id'))
                ->where('locale', 'en')->value('city_name');
            if (is_string($name) && $name !== '') {
                $city = $name;
            }
        }

        return [
            'first_name' => $first,
            'last_name' => $last,
            'street' => $street,
            'phone_number' => $phone,
            'city' => $city,
            'country' => 'Egypt',
            'email' => $email,
        ];
    }

    private function guestToken(Request $request): ?string
    {
        $identity = $request->attributes->get(CompatGuestCart::ATTRIBUTE);
        if ($identity instanceof CartIdentity && $identity->guestToken !== null) {
            return $identity->guestToken;
        }
        $header = $request->header(CompatGuestCart::HEADER);

        return is_string($header) && $header !== '' ? $header : null;
    }

    private function nullableString(mixed $value): ?string
    {
        return is_scalar($value) && (string) $value !== '' ? (string) $value : null;
    }
}
